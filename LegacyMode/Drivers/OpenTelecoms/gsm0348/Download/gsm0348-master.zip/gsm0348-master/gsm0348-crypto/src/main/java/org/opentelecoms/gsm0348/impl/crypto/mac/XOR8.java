package org.opentelecoms.gsm0348.impl.crypto.mac;

public class XOR8 extends AbstractXorMac {

  public XOR8() {
    super("XOR8", 8);
  }

}
