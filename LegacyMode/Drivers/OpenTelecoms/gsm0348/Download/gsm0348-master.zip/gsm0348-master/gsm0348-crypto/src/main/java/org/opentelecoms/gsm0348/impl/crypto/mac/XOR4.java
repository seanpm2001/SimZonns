package org.opentelecoms.gsm0348.impl.crypto.mac;

public class XOR4 extends AbstractXorMac {

  public XOR4() {
    super("XOR4", 4);
  }

}
