package org.opentelecoms.gsm0348.impl.crypto;

public interface CipherParameters
{

}
